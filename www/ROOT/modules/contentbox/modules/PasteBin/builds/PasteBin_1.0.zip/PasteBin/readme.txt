<!-----------------------------------------------------------------------
********************************************************************************
Copyright 2009 ColdBox Framework by Luis Majano and Ortus Solutions, Corp
www.coldboxframework.com | www.luismajano.com | www.ortussolutions.com
********************************************************************************

Author 	 :	Luis Majano
Description :

This module allows you to add pastebin embedded snippets into your pages. You will need to fill out your
developer API key from pastebin for this module to work.

For more information visit: http://pastebin.com/api

======================================================================
CHANGELOG
======================================================================

Version 1.0
# Initial Release