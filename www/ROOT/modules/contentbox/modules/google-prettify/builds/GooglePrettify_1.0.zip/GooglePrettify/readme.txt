<!-----------------------------------------------------------------------
********************************************************************************
Copyright 2009 ColdBox Framework by Luis Majano and Ortus Solutions, Corp
www.coldboxframework.com | www.luismajano.com | www.ortussolutions.com
********************************************************************************

Author 	 :	Luis Majano
Description :

This modules allows you to insert code into your posts that will be prettifyed via
Google Prettify.  In order for this to work, the layouts must implement the "cbui_beforeBodyEnd"

http://google-code-prettify.googlecode.com/svn/trunk/README.html

======================================================================
CHANGELOG
======================================================================

Version 1.0
# Initial Release